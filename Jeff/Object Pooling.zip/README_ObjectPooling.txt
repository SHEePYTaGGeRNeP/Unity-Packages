The issue with Instantition and Destroy is that overtime the Garbage Collector will hiccup and possible freeze
This is a huge Optimization boost for mobile.

TIPS

These Examples can be found under the 'PoolTestManager' script:
To Create a new pool of objects use
PoolManager.instance.CreatePool(GameObject prefab, int NumberOfObjects);

To use an object from a pool call
PoolManager.instance.ReuseObject(GameObject prefab, Vector3 position, Quaternion rotation);


These Examples can be found under the 'PoolTestObject' script:
To reset an object the way you like in the event it changed while active put this function in the prefabs script
public override void ResetObject(){
	//Whatever you want to reset here
}
Also, make sure it is extending ": PoolObject" (Instead of MonoBehaviour)

You can also call Destroy() from the PoolObject class to make the pooled object inactive

___

Feel Free to Delete the 'Test' folder once you understand the pooling functions

The only scripts you need are PoolManager and PoolObject