Sebastian Lague Tutorial: https://www.youtube.com/watch?v=-L-WgKMFuhE&list=PLFt_AvWsXl0cq5Umv3pMC9SPnKjfp9eGW&index=1

Make sure you set your Obstacles on a layer named "unwalkable"
Make sure you set the 'UnwalkableMask' variable under the A* GameObject to unwalkable

The Position objects are ordered to move to is under the A* GameObject in the Grid Script

There's a 2D and 3D package! There's also packages with Weights.

Attach the Unit script to an object and sets its destination
Currently it moves towards its destination once the "Space Bar" is pressed (You can change this under the Unit Script)



Steps I made to convert the 3D package to 2D package:
In CreateGrid() change all "Vector.Forward" to "Vector.Up"
In NodeFromWorldPoint() change "worldPosition.z" to "worldPosition.y"
In OnDrawGizmos() change "new Vector3(gridWorldSize.x,1,gridWorldSize.y)" to "new Vector3(gridWorldSize.x,gridWorldSize.y,1 )"


If you decide you want to use weights and you started without weights there is an 'Add_Weights.txt' that tells you what to change to get it implemented properly.


Made with unity version 5.2.3