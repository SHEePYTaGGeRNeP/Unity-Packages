﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class FadeIn : MonoBehaviour {
	public Image fader;
	Color lessA;

	AsyncOperation async;

	// Use this for initialization
	void Start () {
		lessA = new Color (0, 0, 0, 1);

		StartCoroutine (LunaWolfStudios ());
		StartCoroutine (Load ());
	}

	IEnumerator LunaWolfStudios(){
		while (lessA.a > 0){
			lessA.a -= .02f;
			fader.color = lessA;
			yield return new WaitForSeconds(.02f);
		}
		ActivateScene(); //Activate the scene once the logo stops loading
	}

	IEnumerator Load(){
		//In place for tutorial info
		/*if (PlayerPrefs.GetInt ("firstRun") >= 1){ //Check to see if the game has been played before
			//Check to see if its the first time or you should go straight to the menu
			if (PlayerPrefs.GetInt ("firstRunMenu") == 0){
				PlayerPrefs.SetInt ("firstRunMenu", 1);
			}
			async = SceneManager.LoadSceneAsync ("Menu");
		}else{
			async = SceneManager.LoadSceneAsync("Game");
		}*/
		async = SceneManager.LoadSceneAsync("menu");
		async.allowSceneActivation = false;
		yield return async;
	}

	public void ActivateScene(){
		async.allowSceneActivation = true;
	}

}
