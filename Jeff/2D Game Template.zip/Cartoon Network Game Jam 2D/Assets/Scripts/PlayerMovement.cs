﻿using UnityEngine;
using System.Collections;

public class PlayerMovement : MonoBehaviour {
	public GameObject fallingShot;
	public GameObject stillShot;
	public GameObject arrow;
	public GameObject arrowSpawn;

	float speed = 5.0f;
	float jumpForce = 13.25f;
	float fallForce = 1.0f;

	Animator playerAnimator;
	Rigidbody2D rb2d;
	SpriteRenderer playerSprite;
	Collider2D playerCollider;

	bool isGrounded = false;

	float yVelocity;

	// Use this for initialization
	void Start () {
		playerAnimator = GetComponent<Animator>();
		rb2d = GetComponent<Rigidbody2D>();
		playerSprite = GetComponent<SpriteRenderer>();
		playerCollider = GetComponent<Collider2D>();
	}
	
	// Update is called once per frame
	void Update () {
		//Follow Finger/Mouse Rotation
		/*Vector3 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
		Quaternion rot = Quaternion.LookRotation(transform.position - mousePosition, Vector3.forward);

		transform.rotation = rot;
		transform.eulerAngles = new Vector3(0, 0, transform.eulerAngles.z); //Strip x/y rotation changes*/
		
		//Simple Touch Controls
		if (Input.touchCount == 1){
			//Get the touch
			Touch touch = Input.GetTouch(0);
					
			//See if the Sheep should go left or right
			if (touch.position.x < Screen.width/2){
				//Left
			}else if (touch.position.x > Screen.width/2){
				//Right
			}
		}else if (Input.touchCount == 2){ 
			//On double tap jump
		}else{
		
		}
		
		//Shooting
		if (Input.GetKeyDown("space")) {
			StopCoroutine("ShootAnimation");
			StartCoroutine("ShootAnimation");
			Instantiate(arrow, arrowSpawn.transform.position, transform.rotation);
        }

		//Running
		if (Input.GetKey("left") || Input.GetKey("a")) {
			transform.eulerAngles = new Vector3(0, 180, 0);
			transform.Translate(Vector2.right * (Time.deltaTime * speed));
			playerAnimator.SetBool("isRunning", true);
		} else if (Input.GetKey("right") || Input.GetKey("d")) {
			transform.eulerAngles = new Vector3(0, 0, 0);
			transform.Translate(Vector2.right * (Time.deltaTime * speed));
			playerAnimator.SetBool("isRunning", true);
		} else {
			playerAnimator.SetBool("isRunning", false);
		}

		//Make sure player is grounded before they jump
		if ((Input.GetKey("up") || Input.GetKey("w")) && isGrounded) {
			playerAnimator.SetBool("isJumping", true);
			rb2d.velocity = new Vector2(0, jumpForce);
			isGrounded = false;
			playerCollider.enabled = false;
		}

		//Check to see if falling or jumping
		yVelocity = rb2d.velocity.y;
		
        if (yVelocity < -.5f) { //Falling
			playerAnimator.SetBool("isJumping", false);
			//Don't enable the collider if you are already falling (in case you press down arrow)
			if (!playerAnimator.GetBool("isFalling")){
				playerCollider.enabled = true;
				playerAnimator.SetBool("isFalling", true);
				isGrounded = false;
			}
		} else if (yVelocity > 0) { //Jumping
			playerAnimator.SetBool("isFalling", false);
		} else {
			playerAnimator.SetBool("isFalling", false);
			isGrounded = true; //Grounded
			
		}

		//Fall through the platform you are on
		if ((Input.GetKey("down") || Input.GetKey("s")) && isGrounded && transform.position.y > -3.0f) {			
			StartCoroutine(DropFromPlatform());
		}

		transform.position = new Vector2(Mathf.Clamp(transform.position.x, -7.05f, 7.05f), transform.position.y);
	}

	//You fell from the platform pressing Down
	IEnumerator DropFromPlatform() {
		isGrounded = false;
        rb2d.velocity = new Vector2(0, -fallForce);
		playerAnimator.SetBool("isFalling", true);
		playerCollider.enabled = false;
		yield return new WaitForSeconds(.15f);
		playerCollider.enabled = true;
    }

	//You firin' your arrow
	IEnumerator ShootAnimation() {
        playerSprite.enabled = false;

		if (isGrounded) {
			stillShot.SetActive(true);
		} else {
			fallingShot.SetActive(true);
		}

		yield return new WaitForSeconds(.15f);

		playerSprite.enabled = true;
		fallingShot.SetActive(false);
		stillShot.SetActive(false);
	}
}
