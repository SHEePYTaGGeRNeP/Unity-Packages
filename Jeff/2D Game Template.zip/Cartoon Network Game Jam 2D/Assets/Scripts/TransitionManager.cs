﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class TransitionManager : MonoBehaviour {
	public GameObject faderObject;
	public Image fader;
	Color fadeTransparency;

	AsyncOperation async;

	void OnLevelWasLoaded(int level) {
		StartCoroutine(FadeIn());
	}

	void Awake() {
		//Only 1 gameManager
		if (GameObject.FindGameObjectsWithTag("transitionManager").Length == 0) {
			gameObject.tag = "transitionManager";
			DontDestroyOnLoad(gameObject);
		} else {
			Destroy(gameObject);
		}
	}

	// Use this for initialization
	void Start() {
		fadeTransparency = new Color(0, 0, 0, .04f); //Amount to change per iteration
	}

	public void PlayGame() {
		StartCoroutine(FadeOut());
		StartCoroutine(Load("game"));
	}

	public void ReturnToMenu() {
		StartCoroutine(FadeOut());
		StartCoroutine(Load("menu"));
	}

	//Iterate the fader transparency to 1
	IEnumerator FadeOut() {
		faderObject.SetActive(true);
		while (fader.color.a < 1) {
			fader.color += fadeTransparency;
			yield return new WaitForSeconds(.02f);
		}
		ActivateScene(); //Activate the scene when the fade ends
	}

	//Iterate the fader transparency to 0
	IEnumerator FadeIn() {
		while (fader.color.a > 0) {
			fader.color -= fadeTransparency;
			yield return new WaitForSeconds(.02f);
		}
		faderObject.SetActive(false);
	}

	IEnumerator Load(string sceneName) {
		async = SceneManager.LoadSceneAsync(sceneName);
		async.allowSceneActivation = false;
		yield return async;
	}

	public void ActivateScene() {
		async.allowSceneActivation = true;
	}
}
