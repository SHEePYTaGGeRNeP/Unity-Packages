﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class AudioManager : MonoBehaviour {
	public AudioClip buttonClicked;
	public AudioClip buttonHovered;
	public AudioClip[] arrExample;

	AudioSource[] mainAudioSources; //Array of all audio sources
	AudioSource bgmSource; //Background Music
	AudioSource guiSource; //User Interface

	void OnLevelWasLoaded(int level){
		if (level == 1) { //menu
			//Menu Music this can just be set already in the inspector window
		}else if (level == 2) { //game
			//Game Music?
		}
	}

	void Awake() {
		mainAudioSources = GetComponents<AudioSource>();

		bgmSource = mainAudioSources[0];
		guiSource = mainAudioSources[1];
		
		//Make sure only 1 per scene
		if (GameObject.FindGameObjectsWithTag ("audioManager").Length == 0){
			gameObject.tag = "audioManager";
			DontDestroyOnLoad(gameObject);
		}else{
			Destroy (gameObject);
		}

		
		if (!PlayerPrefs.HasKey ("sfxVolume")){ //Set sfxVolume to 1/2 initially
			PlayerPrefs.SetFloat ("sfxVolume", .5f);
		}

		if (!PlayerPrefs.HasKey("bgmVolume")) { //Set bgmVolume to 1/4 initially
			PlayerPrefs.SetFloat("bgmVolume", .25f);
		}

		//Create more audio sources following (Clip, Loop, PlayOnAwake, Volume)
		//createAudioSource = AddAudio (myClip, false, false, PlayerPrefs.GetFloat ("sfxVolume"));
	}

	// Use this for initialization
	void Start () {
		ChangeVolume(PlayerPrefs.GetFloat("bgmVolume"), PlayerPrefs.GetFloat("sfxVolume"));
	}

	//Choose the clip then play it through a specified source
	public void ButtonHovered() {
		guiSource.clip = buttonHovered;
		guiSource.Play();
	}

	public void ButtonClicked() {
		guiSource.clip = buttonClicked;
		guiSource.Play();
	}

	public void ChangeVolume(float bgmVolume, float sfxVolume){
		bgmSource.volume = bgmVolume;

		//All the SFX volume should be the same
		for (int i = 1; i < mainAudioSources.Length; i++) {
			mainAudioSources[i].volume = sfxVolume;
		}
	}

	//Used to make a new audio source 
	public AudioSource AddAudio(AudioClip clip, bool loop, bool playOnAwake, float vol){
		AudioSource newAudio = gameObject.AddComponent<AudioSource>();
		newAudio.clip = clip;
		newAudio.loop = loop;
		newAudio.volume = vol;
		newAudio.playOnAwake = playOnAwake;
		return (newAudio);
	}

	//Play specific track
	public void PlayTrack(AudioSource audio) {
		audio.Play();
	}

	//Stop specific track
	public void StopTrack(AudioSource audio) {
		audio.Stop();
	}

	//Change pitch
	public void SetPitch(AudioSource audio, float value) {
		audio.pitch = value;
	}

	//Either fade in or out over time to a desiredVolume
	public void FadeTrack(AudioSource audio, bool fadeOut) {
		if (fadeOut) {
			StartCoroutine(FadeOut(audio));
		} else {
			StartCoroutine(FadeIn(audio));
		}
	}

	IEnumerator FadeOut(AudioSource audio) {
		float oldVolume = audio.volume;

		while (audio.volume > 0) {
			audio.volume -= .01f;
			yield return new WaitForSeconds(.03f);
		}

		StopTrack(audio);
		audio.volume = oldVolume;
	}

	IEnumerator FadeIn(AudioSource audio) {
		float oldVolume = audio.volume;

		audio.volume = 0;
		PlayTrack(audio);

		while (audio.volume < oldVolume) {
			audio.volume += .01f;
			yield return new WaitForSeconds(.03f);
		}
	}
}
