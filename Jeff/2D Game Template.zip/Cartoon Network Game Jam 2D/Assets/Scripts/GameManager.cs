﻿using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour {
	GameObject transitionManager;

	// Use this for initialization
	void Start () {
		transitionManager = GameObject.FindGameObjectWithTag("transitionManager");
	}

	public void PlayGame() {
		transitionManager.GetComponent<TransitionManager>().PlayGame();
	}

	public void GoToMenu() {
		transitionManager.GetComponent<TransitionManager>().ReturnToMenu();
	}
}
